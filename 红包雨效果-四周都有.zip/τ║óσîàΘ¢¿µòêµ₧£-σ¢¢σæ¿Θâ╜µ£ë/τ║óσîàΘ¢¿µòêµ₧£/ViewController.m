//
//  ViewController.m
//  红包雨效果
//
//  Created by LJP on 18/1/18.
//  Copyright © 2018年 poco. All rights reserved.
//

#import "ViewController.h"
#import <SceneKit/SceneKit.h>
#import <ARKit/ARKit.h>

@interface ViewController ()<ARSCNViewDelegate>

//视图
@property(nonatomic, strong) ARSCNView * jpARSCNView;

//会话
@property(nonatomic, strong) ARSession * jpARSession;

//跟踪会话
@property(nonatomic, strong) ARWorldTrackingConfiguration * jpARWTkConfiguration;

@end

@implementation ViewController

#pragma mark ============================== 生命周期 ==============================

- (void)viewDidLoad {
    [super viewDidLoad];
}

- (void)viewWillAppear:(BOOL)animated {
    
    [super viewWillAppear:animated];
    
    [self.view addSubview:self.jpARSCNView];
    
    //场景运行并且设置跟踪会话
    [self.jpARSession runWithConfiguration:self.jpARWTkConfiguration];
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    
    [self.jpARSCNView.session pause];
}


#pragma mark ============================== 私有方法 ==============================


- (void)addNode{
    
    for (int i = -2 ; i<2; i ++) {
        for (int j = -2; j<2; j++) {
            
            SCNVector3 position = SCNVector3Make(i*5 +[self getRandomNumber:-3 to:3], 30, j*5+[self getRandomNumber:-3 to:3]);
            
            NSLog(@"x == %lf  z == %lf",position.x,position.z);
            
            if (position.x == 0 && position.z == 0){}else{
                [self initNodeWithPosition:position];
            }
        
        }
    }
    
}

//获取一个随机整数，范围在[from,to），包括from，不包括to
-(int)getRandomNumber:(int)from to:(int)to
{
    return (int)(from + (arc4random() % (to - from + 1)));
}

- (void)initNodeWithPosition:(SCNVector3)position {
    
    SCNGeometry * geometer = [SCNGeometry geometry];
    
    geometer = [SCNBox boxWithWidth:1.0 height:1.0 length:0.01 chamferRadius:0];
    
    SCNMaterial * material = [[SCNMaterial alloc]init];
    
    material.diffuse.contents = [UIImage imageNamed:@"honbao.png"];
    
    geometer.materials = @[material,material,material,material,material,material];
    
    SCNNode *geometerNode = [SCNNode nodeWithGeometry:geometer];
    
    geometerNode.physicsBody = [SCNPhysicsBody bodyWithType:SCNPhysicsBodyTypeDynamic shape:nil];
    
    //设置力
    NSInteger X = (NSInteger)(arc4random_uniform(9)) - 4;
    
    NSInteger Y = (NSInteger) (1 );
    
    NSInteger Z = (NSInteger)(arc4random_uniform(9)) - 4;
    
    [geometerNode.physicsBody applyForce:SCNVector3Make(X, -Y, Z) atPosition:SCNVector3Make(0.05, 0.05, 0.05) impulse:YES];
    
    geometerNode.position = position;
    
    [self.jpARSCNView.scene.rootNode addChildNode:geometerNode];
    
}


- (void)clean {
    
    for (SCNNode *node in self.jpARSCNView.scene.rootNode.childNodes) {

        if (node.presentationNode.position.y < -26) {
            
            @try {
                [node removeFromParentNode];
            } @catch (NSException *exception) {
                NSLog(@"%s:%@",__func__,exception.description);
            }
            
        }
    }
    
}

#pragma mark ============================== 代理方法 ==============================
- (void)renderer:(id<SCNSceneRenderer>)renderer updateAtTime:(NSTimeInterval)time {
    //太快了 限制一下
    if (arc4random()%3 == 0) {
        [self addNode];
        [self clean];
    }
    
    
}

#pragma mark ============================== 访问器方法 ==============================
- (ARSCNView *)jpARSCNView {
    
    if (_jpARSCNView == nil) {
        _jpARSCNView = [[ARSCNView alloc]init];
        _jpARSCNView.frame = self.view.frame;
        _jpARSCNView.session = self.jpARSession;
        _jpARSCNView.automaticallyUpdatesLighting = YES;
        _jpARSCNView.delegate = self;
        _jpARSCNView.scene = [SCNScene new];
    }
    
    return _jpARSCNView;
}

- (ARSession *)jpARSession {
    
    if (_jpARSession == nil) {
        _jpARSession = [[ARSession alloc]init];
    }
    
    return _jpARSession;
    
}

- (ARWorldTrackingConfiguration *)jpARWTkConfiguration {
    
    if (_jpARWTkConfiguration == nil) {
        _jpARWTkConfiguration = [[ARWorldTrackingConfiguration alloc]init];
        _jpARWTkConfiguration.planeDetection = ARPlaneDetectionHorizontal;
        _jpARWTkConfiguration.lightEstimationEnabled = YES;
    }
    
    return _jpARWTkConfiguration;
    
}

@end
