//
//  ViewController.m
//  点击3D模型
//
//  Created by LJP on 8/12/17.
//  Copyright © 2017年 poco. All rights reserved.
//

#import "ViewController.h"

@interface ViewController () <ARSCNViewDelegate>

//视图
@property(nonatomic, strong) ARSCNView * jpARSCNView;

//会话
@property(nonatomic, strong) ARSession * jpARSession;

//跟踪会话
@property(nonatomic, strong) ARWorldTrackingConfiguration * jpARWTkConfiguration;

//盒子
@property(nonatomic, strong) SCNBox * jpBox;

//节点
@property(nonatomic, strong) SCNNode * jpNode;

@end

    
@implementation ViewController

- (void)viewDidLoad {
    
    [super viewDidLoad];
    
    [self initUI];
    
}

- (void)viewWillAppear:(BOOL)animated {
    
    [super viewWillAppear:animated];
    
    [self.jpARSCNView.session runWithConfiguration:self.jpARWTkConfiguration];
    
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {

    // 获取到手势的对象
    UITouch *touch = [touches allObjects].firstObject;
    
    // 手势在SCNView中的位置
    CGPoint touchPoint = [touch locationInView:self.jpARSCNView];
    
    //该方法会返回一个SCNHitTestResult数组，这个数组中每个元素的node都包含了指定的点（CGPoint）
    NSArray *hitResults = [self.jpARSCNView hitTest:touchPoint options:nil];
    
    if (hitResults.count > 0) {
        
        SCNHitTestResult * hit = [hitResults firstObject];
        
        SCNNode *node = hit.node;

        if (node.geometry == self.jpBox) {
            NSLog(@"点击了箱子");
            [self removeBox];
            [self addBox];
            
        }
        
    }

}

- (void)removeBox{
    //清除旧盒子
    [self.jpNode removeFromParentNode];
}

- (void)addBox{
    
    SCNScene * jpScene = [[SCNScene alloc]init];
    
    _jpBox = [SCNBox boxWithWidth:0.1 height:0.1 length:0.1 chamferRadius:0];
    
    SCNNode * jpNode = [SCNNode nodeWithGeometry:_jpBox];
    
    jpNode.name = @"jpNode";
    
    jpNode.position = SCNVector3Make([self floatBetween], [self floatBetween], -1);
    
    [jpScene.rootNode addChildNode:jpNode];
    
    self.jpNode = jpNode;
    
    self.jpARSCNView.scene = jpScene;
    
}

- (void)initUI {
    
    [self.view addSubview:self.jpARSCNView];
    
    [self addBox];
    
}

//生产随机数
- (CGFloat )floatBetween {
    
    CGFloat a = (float)(1+arc4random()%99)/100-0.5;
    
    NSLog(@"a == %f",a);
    
    return a;
    
}


#pragma mark - 访问器方法

- (ARSCNView *)jpARSCNView {
    
    if (_jpARSCNView == nil) {
        _jpARSCNView = [[ARSCNView alloc]init];
        _jpARSCNView.frame = self.view.frame;
        _jpARSCNView.session = self.jpARSession;
        
        //自动刷新灯光
        _jpARSCNView.automaticallyUpdatesLighting = YES;
        
        _jpARSCNView.showsStatistics = YES;
        
        //添加默认灯光效果
        _jpARSCNView.autoenablesDefaultLighting = YES;
        
        _jpARSCNView.delegate = self;
        
    }
    
    return _jpARSCNView;
}

- (ARSession *)jpARSession {
    
    if (_jpARSession == nil) {
        _jpARSession = [[ARSession alloc]init];
        
    }
    
    return _jpARSession;
    
}

- (ARWorldTrackingConfiguration *)jpARWTkConfiguration {
    
    if (_jpARWTkConfiguration == nil) {
        _jpARWTkConfiguration = [[ARWorldTrackingConfiguration alloc]init];
        _jpARWTkConfiguration.planeDetection = ARPlaneDetectionHorizontal;
        _jpARWTkConfiguration.lightEstimationEnabled = YES;
        
    }
    
    return _jpARWTkConfiguration;
    
}

/*
 - (NSArray<SCNHitTestResult *> *)hitTest:(CGPoint)point options:(nullable NSDictionary<SCNHitTestOption, id> *)options;
 
 该方法会返回一个SCNHitTestResult数组，这个数组中每个元素的node都包含了指定的点（CGPoint）
 
 打个比方：ARSCNView就是个多层合成木板，手指的每次点击，都好像一根针穿透模板，该方法会反回由针穿过的所有点（node）组成的一饿数组，每个点其实都包含了你手指点击的位置（CGPoint），这样我们就可以通过便利每个数组中每个SCNHitTestResult的node，看哪个node有父node，并且找到node的name和3D模型的根节点name做对比，可以找到那就是点击到了3D模型；
 
 */

@end
