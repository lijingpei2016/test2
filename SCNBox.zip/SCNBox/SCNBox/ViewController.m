//
//  ViewController.m
//  SCNBox
//
//  Created by LJP on 5/12/17.
//  Copyright © 2017年 poco. All rights reserved.
//

#import "ViewController.h"

@interface ViewController () <ARSCNViewDelegate>

@property (nonatomic, strong) ARSCNView * jpARSCNView;

@property (nonatomic, strong) ARWorldTrackingConfiguration * jpARWTkConfiguration;

@property (nonatomic, strong) ARSession * jpARSession;

@end

    
@implementation ViewController

- (void)viewWillAppear:(BOOL)animated {
    
    [super viewWillAppear:animated];
    
    [self.view addSubview:self.jpARSCNView];
    
    [self.jpARSession runWithConfiguration:self.jpARWTkConfiguration];
    
    [self add3D];
    
}

- (void)add3D {
    
    SCNScene * jpScene = [[SCNScene alloc]init];

    SCNBox * jpBox = [SCNBox boxWithWidth:0.1 height:0.1 length:0.1 chamferRadius:0];

    SCNNode * jpNode = [SCNNode nodeWithGeometry:jpBox];

    jpNode.position = SCNVector3Make(0, 0, -0.5);

    [jpScene.rootNode addChildNode:jpNode];
    
    self.jpARSCNView.scene = jpScene;
    
}


- (ARSCNView *)jpARSCNView {
    
    if (_jpARSCNView == nil) {
        
        _jpARSCNView = [[ARSCNView alloc]init];
        _jpARSCNView.delegate = self;
        _jpARSCNView.frame = self.view.frame;
        _jpARSCNView.session = self.jpARSession;
        _jpARSCNView.autoenablesDefaultLighting = YES;
        
    }
    
    return _jpARSCNView;
    
}

- (ARSession *)jpARSession {
    
    if (_jpARSession == nil) {
        _jpARSession = [[ARSession alloc]init];
    }
    return _jpARSession;
    
}

- (ARWorldTrackingConfiguration *)jpARWTkConfiguration {
    
    if (_jpARWTkConfiguration == nil) {
        _jpARWTkConfiguration = [[ARWorldTrackingConfiguration alloc]init];
        _jpARWTkConfiguration.planeDetection = ARPlaneDetectionHorizontal;
        _jpARWTkConfiguration.lightEstimationEnabled = YES;
        
    }
    
    return _jpARWTkConfiguration;
}


@end
