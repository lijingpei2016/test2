//
//  AppDelegate.h
//  试试自己封装的类
//
//  Created by LJP on 29/1/18.
//  Copyright © 2018年 poco. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

