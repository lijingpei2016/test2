//
//  ViewController.m
//  试试自己封装的类
//
//  Created by LJP on 29/1/18.
//  Copyright © 2018年 poco. All rights reserved.
//

#import "ViewController.h"
#import "JPARSCNView.h"

@interface ViewController ()<JPARViewDelegate>

@property (nonatomic, strong)JPARSCNView * jpView;

@end

@implementation ViewController


- (void)viewWillAppear:(BOOL)animated {
    
    [super viewWillAppear:animated];
    
    [self initUI];
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    
    [self.jpView stopRunning];
}

- (void)initUI {
    
    self.jpView = [[JPARSCNView alloc]init];
    self.jpView.frame = CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, ([UIScreen mainScreen].bounds.size.width)/9*16);
    self.jpView.JPARViewDelegate = self;
    [self.jpView startRunning];

    self.view.userInteractionEnabled = YES;
    [self.view addSubview:self.jpView];
    
//    [self.jpView addNode];
     SCNScene * myScene = [SCNScene sceneNamed:@"art.scnassets/ARTest3/3.DAE"];
    
    [self.jpView addNodeWithScene:myScene];
    [self.jpView ScaleOfNodeWithScale:0.15];
    [self.jpView NodePositionWithX:0 y:-10 z:-50];
}

- (void)originalImageWith:(CVPixelBufferRef)pixelBuffer {
    
    
    
    
//    [self.jpView refreshBackgroundWithLayer:nil];
  
}



@end
