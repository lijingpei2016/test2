//
//  JPARSCNView.m
//  手势交互
//
//  Created by LJP on 29/1/18.
//  Copyright © 2018年 poco. All rights reserved.
//

#import "JPARSCNView.h"

@interface JPARSCNView ()<ARSCNViewDelegate,ARSessionDelegate>

//跟踪会话
@property(nonatomic, strong) ARWorldTrackingConfiguration * jpARWTkConfiguration;

@property (nonatomic, assign) CGFloat tempScale;
@property (nonatomic, assign) CGFloat tempRotation;
@property (nonatomic, assign) CGPoint tempPoint;
@property (nonatomic, assign) SCNVector3 tempPosition;

@property (nonatomic, strong) SCNNode * node;

@end

@implementation JPARSCNView

- (instancetype)init {
    
    self = [super init];
    
    if (self) {
        
        [self initData];
        [self initGestureRecognizer];
        
    }
    
    return self;
}

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        
        [self initData];
        [self initGestureRecognizer];
        
    }
    return self;
    
}


#pragma mark ===================== 私有方法 =====================

- (void)initData {
    
    self.delegate = self;
    self.session.delegate = self;
    
    self.tempScale = 1.0;
    self.tempRotation = 0.0;
    
}

- (void)initGestureRecognizer {
    
    self.userInteractionEnabled = YES;
    
    UIPinchGestureRecognizer *pinch = [[UIPinchGestureRecognizer alloc] initWithTarget:self action:@selector(handlePinch:)];
    [self addGestureRecognizer:pinch];
    
    
    UIRotationGestureRecognizer *rotation = [[UIRotationGestureRecognizer alloc] initWithTarget:self action:@selector(handleRotation:)];
    [self addGestureRecognizer:rotation];
    
    
    UILongPressGestureRecognizer * longPress = [[UILongPressGestureRecognizer alloc]initWithTarget:self action:@selector(lonePressMoving:)];
    longPress.minimumPressDuration = 0.1;
    
    [self addGestureRecognizer:longPress];
    
    
    UISwipeGestureRecognizer *swipeGesture = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(swipeGesture:)];
    
    swipeGesture.direction = UISwipeGestureRecognizerDirectionRight; //默认向右
    swipeGesture.numberOfTouchesRequired = 2;
    
    [self addGestureRecognizer:swipeGesture];
    
    
    UISwipeGestureRecognizer *swipeGestureLeft = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(swipeGesture:)];
    
    swipeGestureLeft.numberOfTouchesRequired = 2;
    
    swipeGestureLeft.direction = UISwipeGestureRecognizerDirectionLeft;
    
    [self addGestureRecognizer:swipeGestureLeft];
    
}

#pragma mark ===================== 事件处理 =====================

- (void)handlePinch:(UIPinchGestureRecognizer *)recognizer {
    
    CGFloat scale = recognizer.scale;
    
    if (recognizer.state == UIGestureRecognizerStateChanged) {
        self.node.scale = SCNVector3Make(self.tempScale*scale, self.tempScale*scale, self.tempScale*scale);
    }
    
    if (recognizer.state == UIGestureRecognizerStateEnded) {
        self.tempScale = self.tempScale * scale;
    }
    
}


- (void)handleRotation:(UIRotationGestureRecognizer *)recognizer {
    
    CGFloat rotation = recognizer.rotation;
    
    if (recognizer.state == UIGestureRecognizerStateChanged) {
        self.node.rotation = SCNVector4Make(0, 1, 0, M_PI *(self.tempRotation + rotation));
    }
    
    if (recognizer.state == UIGestureRecognizerStateEnded) {
        self.tempRotation = self.tempRotation + rotation;
    }
    
}

- (void)lonePressMoving:(UILongPressGestureRecognizer *)longPress {
    
    if (longPress.state == UIGestureRecognizerStateBegan) {
        self.tempPoint = [longPress locationInView:self];
        self.tempPosition = self.node.position;
        
    }
    
    
    if (longPress.state == UIGestureRecognizerStateChanged) {
        
        CGPoint point = [longPress locationInView:self];
        
        self.node.position = SCNVector3Make(self.tempPosition.x -(self.tempPoint.x-point.x)/100 ,self.tempPosition.y +(self.tempPoint.y-point.y)/100, self.tempPosition.z);
        
    }
    
    if (longPress.state == UIGestureRecognizerStateEnded) {
    }
    
    
}


- (void)swipeGesture:(id)sender {
    
    UISwipeGestureRecognizer *swipe = sender;
    
    if (swipe.direction == UISwipeGestureRecognizerDirectionLeft) {
        self.node.rotation = SCNVector4Make(0, 1, 0, M_PI *(self.tempRotation + 0.25));
        self.tempRotation += 0.25;
    }
    
    if (swipe.direction == UISwipeGestureRecognizerDirectionRight) {
        self.node.rotation = SCNVector4Make(0, 1, 0, M_PI *(self.tempRotation - 0.25));
        self.tempRotation -= 0.25;
        
    }
    
}

#pragma mark ===================== 代理方法 =====================
- (void)session:(ARSession *)session didUpdateFrame:(ARFrame *)frame {
    
    CVPixelBufferRef pixelBuffer = frame.capturedImage;
    
    [self.JPARViewDelegate originalImageWith:pixelBuffer];
    
}

//检测到平面
- (void)renderer:(id<SCNSceneRenderer>)renderer didAddNode:(SCNNode *)node forAnchor:(ARAnchor *)anchor {
    NSLog(@"添加");
   
}

-(void)renderer:(id<SCNSceneRenderer>)renderer didUpdateNode:(SCNNode *)node forAnchor:(ARAnchor *)anchor {
    NSLog(@"刷新");
   
}

-(void)renderer:(id<SCNSceneRenderer>)renderer didRemoveNode:(SCNNode *)node forAnchor:(ARAnchor *)anchor {
     NSLog(@"删除");
}


#pragma mark ===================== 类或对象方法 =====================

- (void)startRunning {
    [self.session runWithConfiguration:self.jpARWTkConfiguration];
}

- (void)stopRunning {
    [self.session pause];
}

- (void)addNode {
    
    [self.scene.rootNode enumerateChildNodesUsingBlock:^(SCNNode * _Nonnull child, BOOL * _Nonnull stop) {
        if ([child.name isEqual: @"node"]) {
            [child removeFromParentNode];
        }
    }];
    
    
    SCNGeometry *geometer = [SCNGeometry geometry];
    
    geometer = [SCNBox boxWithWidth:1 height:1 length:1 chamferRadius:0];
    
    SCNNode * node = [SCNNode nodeWithGeometry:geometer];
    
    node.geometry.firstMaterial.diffuse.contents = [UIColor orangeColor];
    
    node.position = SCNVector3Make(0, 2, -2);
    
    node.name = @"node";
    
    self.node = node;
    
    [self.scene.rootNode addChildNode:node];
    
}

- (void)addNodeWithNode:(SCNNode*)node {
    self.node = node;
    node.position = SCNVector3Make(0, 2, -2);
    [self.scene.rootNode addChildNode:node];
}

- (void)addNodeWithScene:(SCNScene*)scene {
    
    SCNNode * node = [[SCNNode alloc]init];
    
    for (SCNNode * child in scene.rootNode.childNodes) {
        
        [node addChildNode:child];
        
    }
    
    node.position = SCNVector3Make(0, 2, -2);
    
    node.scale = SCNVector3Make(self.tempScale, self.tempScale, self.tempScale);
    
    self.node = node;
    
    [self.scene.rootNode addChildNode:node];
    
}

- (void)refreshBackgroundWithLayer:(CALayer *)layer {
    self.scene.background.contents = layer;
}

- (void)ScaleOfNodeWithScale:(CGFloat)scale {
    
    self.node.scale = SCNVector3Make(scale, scale, scale);
    
    self.tempScale = scale;
    
}

- (void)NodePositionWithX:(CGFloat)x y:(CGFloat)y z:(CGFloat)z {
    self.node.position = SCNVector3Make(x, y, z);
}


#pragma mark ===================== 访问器 =====================

- (ARWorldTrackingConfiguration *)jpARWTkConfiguration {
    
    if (_jpARWTkConfiguration == nil) {
        if (@available(iOS 11.0, *)) {
            _jpARWTkConfiguration = [[ARWorldTrackingConfiguration alloc]init];
        } else {
            NSLog(@"不是十一的系统");
        }
        _jpARWTkConfiguration.planeDetection = ARPlaneDetectionHorizontal;
        _jpARWTkConfiguration.lightEstimationEnabled = YES;
    }
    
    return _jpARWTkConfiguration;
    
}

@end
