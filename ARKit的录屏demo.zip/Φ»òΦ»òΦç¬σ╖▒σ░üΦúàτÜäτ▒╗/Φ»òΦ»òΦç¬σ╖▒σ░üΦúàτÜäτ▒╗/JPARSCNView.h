//
//  JPARSCNView.h
//  手势交互
//
//  Created by LJP on 29/1/18.
//  Copyright © 2018年 poco. All rights reserved.
//

#import <ARKit/ARKit.h>
#import <SceneKit/SceneKit.h>

//代理
@protocol JPARViewDelegate <NSObject>

/**
 没有3D模型的场景buffer 这个方法1s走3-4次
 */
- (void)originalImageWith:(CVPixelBufferRef)pixelBuffer;

@end

@interface JPARSCNView : ARSCNView

/**
 代理
 */
@property (nonatomic,weak) id<JPARViewDelegate> JPARViewDelegate;


/**
 开始运行镜头追踪
 */
- (void)startRunning;

/**
 停止运行镜头追踪
 */
- (void)stopRunning;

/**
 添加节点
 */
- (void)addNode;
- (void)addNodeWithNode:(SCNNode *)node;
- (void)addNodeWithScene:(SCNScene *)scene;

/**
 模型的位置
 */
- (void)NodePositionWithX:(CGFloat)x y:(CGFloat)y z:(CGFloat)z;


/**
 模型的缩放
 */
- (void)ScaleOfNodeWithScale:(CGFloat)scale;

/**
 更新滤镜效果
 */
- (void)refreshBackgroundWithLayer:(CALayer *)layer;


@end
