//
//  main.m
//  AR的录屏demo(有声音)
//
//  Created by LJP on 13/12/17.
//  Copyright © 2017年 poco. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
