//
//  ViewController.h
//  AR的录屏demo(有声音)
//
//  Created by LJP on 13/12/17.
//  Copyright © 2017年 poco. All rights reserved.
//

/*
 
 * 思路
 * 录制视频:在SCNRenderer类里把图片截取出来 然后转成CVPixelBufferRef
 * 录制音频:在 (void)captureOutput:(AVCaptureOutput *)output didOutputSampleBuffer:(CMSampleBufferRef)sampleBuffer fromConnection:(AVCaptureConnection *)connection; 代理方法里获取 sampleBuffer
 
 * 注意:在音频的队列里  把音频视频一起写入了  因为开2条线程会崩溃  具体原因不清楚
 
 * 不足:1.截取图片再转成CVPixelBufferRef 很耗性能 机子不好会卡
       2.在一条线程里录制 和网上的demo不一样 不知道会发生什么问题
 
 */

#import "ViewController.h"
//导入录屏的框架
#import <AVFoundation/AVFoundation.h>

//录屏的状态
typedef NS_ENUM(NSInteger, LJPRecordStatus)  {
    LJPRecordStatusIdle,
    LJPRecordStatusRecording,
    LJPRecordStatusFinish,
};

//遵循代理
@interface ViewController () <AVCaptureAudioDataOutputSampleBufferDelegate>

@property (nonatomic, strong) IBOutlet ARSCNView *sceneView;

@property (nonatomic, strong) AVAssetWriter * writer; //负责写的类
@property (nonatomic, strong) AVAssetWriterInput * videoInput;
@property (nonatomic, strong) AVAssetWriterInputPixelBufferAdaptor * pixelBufferAdaptor; //输入的缓存

@property (nonatomic, strong) SCNRenderer * renderer; //渲染器
@property (nonatomic, assign) LJPRecordStatus status; //状态
@property (nonatomic, copy)   NSString * outputPath;  //路径
@property (nonatomic, assign) CGSize outputSize;      //输出的分辨率

@property (strong, nonatomic) AVCaptureAudioDataOutput   * audioOutput;   //音频输出
@property (nonatomic, strong) AVAssetWriterInput         * audioInput;    //写入的类
@property (strong, nonatomic) AVCaptureDeviceInput       * audioMicInput; //麦克风输入
@property (strong, nonatomic) AVCaptureSession           * recordSession; //捕获视频的会话
@property (nonatomic, strong) dispatch_queue_t             audioQueue;    //写入的队列
@property (nonatomic, assign) BOOL isFirstWriter;                         //是否是第一次写入

@end

@implementation ViewController

#pragma mark ======================================= 生命周期 =======================================

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self initData];
    [self initUI];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    ARWorldTrackingConfiguration *configuration = [[ARWorldTrackingConfiguration alloc]init];
    
    [self.sceneView.session runWithConfiguration:configuration];
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    
    [self.sceneView.session pause];
}


#pragma mark ======================================= 私有方法 =======================================

- (void)initData {
    
    self.sceneView.showsStatistics = YES;
    
    SCNScene *scene = [SCNScene sceneNamed:@"art.scnassets/ship.scn"];
    
    self.sceneView.scene = scene;
    
    // 创建SCNRenderer
    self.renderer = [SCNRenderer rendererWithDevice:nil options:nil];
    
    // 将sceneView的sceneView传给renderer
    self.renderer.scene = self.sceneView.scene;
    
    // 创建处理队列
    self.audioQueue = dispatch_queue_create("ljp.audio.queue", NULL);
    
    // 设置输出分辨率
    self.outputSize = CGSizeMake(720, 1280);
    
    self.isFirstWriter = YES;
}

- (void)initUI {
    
    CGRect bounds = [UIScreen mainScreen].bounds;
    
    UIButton *button = [[UIButton alloc] initWithFrame:CGRectMake(bounds.size.width/2-60, bounds.size.height - 200, 120, 100)];
    [button setTitle:@"开始录制" forState:UIControlStateNormal];
    [button setTitle:@"正在录制" forState:UIControlStateSelected];
    [button addTarget:self action:@selector(clicked:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:button];
    
}

//点击按钮
-(void)clicked:(UIButton *)sender {
    
    sender.selected = !sender.selected;
    
    if (sender.selected) {
        [self startRecording];
    }else {
        [self finishRecording];
    }
    
}

//开始录制
- (void)startRecording {
    
    self.status = LJPRecordStatusRecording;
    
    [self setupWriter];
    
}

//结束录制
- (void)finishRecording {
    
    self.status = LJPRecordStatusIdle;
    
    [self.recordSession stopRunning];
    
    [self.videoInput markAsFinished];
    
    [self.audioInput markAsFinished];
    
    [self.writer finishWritingWithCompletionHandler:^{
        
        UISaveVideoAtPathToSavedPhotosAlbum(self.outputPath, nil, nil, nil);
        
        //初始化警告框
        UIAlertController*alert = [UIAlertController
                                   alertControllerWithTitle: @"提示"
                                   message: @"视频已经保存到相册"
                                   preferredStyle:UIAlertControllerStyleAlert];
        
        [alert addAction:[UIAlertAction
                          actionWithTitle:@"确定"
                          style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action)
                          {
                          }]];
        
        //弹出提示框
        [self presentViewController:alert animated:YES completion:nil];
        
    }];
    
}


//录制
- (void)setupWriter {
    
    //设置存储路径
    self.outputPath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES)[0] stringByAppendingPathComponent:@"out.mp4"];
    
    //如果有就先清除
    [[NSFileManager defaultManager] removeItemAtPath:self.outputPath error:nil];
    
    self.writer = [[AVAssetWriter alloc] initWithURL:[NSURL fileURLWithPath:self.outputPath] fileType:AVFileTypeQuickTimeMovie error:nil];
    
    
    [self initVideoInPut];
    
    [self initAudioInput];
    
    [self initPixelBufferAdaptor];
    
    //运行捕获数据的类
    [self.recordSession startRunning];
    
}

- (void)initVideoInPut {
    
    self.videoInput = [[AVAssetWriterInput alloc]
                       initWithMediaType:AVMediaTypeVideo
                       outputSettings   :@{AVVideoCodecKey:AVVideoCodecTypeH264,
                                           AVVideoWidthKey: @(self.outputSize.width),
                                           AVVideoHeightKey: @(self.outputSize.height)}];
    
    if ([self.writer canAddInput:self.videoInput]) {
        [self.writer addInput:self.videoInput];
    }
    
}

- (void)initAudioInput {
    
    AudioChannelLayout stereoChannelLayout = {
        .mChannelLayoutTag = kAudioChannelLayoutTag_Stereo,
        .mChannelBitmap = 0,
        .mNumberChannelDescriptions = 0
    };
    
    // Convert the channel layout object to an NSData object.
    NSData *channelLayoutAsData = [NSData dataWithBytes:&stereoChannelLayout length:offsetof(AudioChannelLayout, mChannelDescriptions)];
    
    // Get the compression settings for 128 kbps AAC.
    NSDictionary *compressionAudioSettings = @{
                                               AVFormatIDKey         : [NSNumber numberWithUnsignedInt:kAudioFormatMPEG4AAC],//AAC编码格式
                                               AVEncoderBitRateKey   : [NSNumber numberWithInteger:128000],// 比特采样率 一般是128000
                                               AVSampleRateKey       : [NSNumber numberWithInteger:44100],//采样率44100
                                               AVChannelLayoutKey    : channelLayoutAsData,
                                               AVNumberOfChannelsKey : [NSNumber numberWithUnsignedInteger:2] //1表示单声道,2表示双声道
                                               };
    //初始化音频写入类
    self.audioInput = [AVAssetWriterInput assetWriterInputWithMediaType:AVMediaTypeAudio outputSettings:compressionAudioSettings];
    
    //表明输入是否应该调整其处理为实时数据源的数据
    self.audioInput.expectsMediaDataInRealTime = YES;
    
    //将音频输入源加入
    if ([self.writer canAddInput:self.audioInput]) {
        [self.writer addInput:self.audioInput];
    }
    
}

- (void)initPixelBufferAdaptor {
    
    self.pixelBufferAdaptor = [[AVAssetWriterInputPixelBufferAdaptor alloc] initWithAssetWriterInput:self.videoInput sourcePixelBufferAttributes:
                               @{(id)kCVPixelBufferPixelFormatTypeKey:@(kCVPixelFormatType_32BGRA),
                                 (id)kCVPixelBufferWidthKey:@(self.outputSize.width),
                                 (id)kCVPixelBufferHeightKey:@(self.outputSize.height)}];
    
}

//音频+samplebuffer
- (void)audioAddSampleBuffer:(CMSampleBufferRef)audioSamplebuffer{
    
    if (audioSamplebuffer == nil && CMTIME_IS_INVALID(CMSampleBufferGetPresentationTimeStamp(audioSamplebuffer))) {
        [self.audioInput markAsFinished];
        return;
    }
    
    if (self.audioInput.isReadyForMoreMediaData) {
        [self.audioInput appendSampleBuffer:audioSamplebuffer];
    }
    
}

//视频+pixelBuffer
- (void)videoAddPixelBufferWithSampleBuffer:(CMSampleBufferRef)sampleBuffer{
    
    CVPixelBufferRef pixelBuffer = [self capturePixelBuffer];
    
    [self.pixelBufferAdaptor appendPixelBuffer:pixelBuffer withPresentationTime:CMSampleBufferGetPresentationTimeStamp(sampleBuffer)];
    
}


// 生成CVPixelBufferRef
-(CVPixelBufferRef)capturePixelBuffer {
    
    //从着色器里获取到图片
    UIImage *image = [self.renderer snapshotAtTime:1 withSize:CGSizeMake(self.outputSize.width, self.outputSize.height) antialiasingMode:SCNAntialiasingModeMultisampling4X];
    
    CVPixelBufferRef pixelBuffer = NULL;
    
    CVPixelBufferPoolCreatePixelBuffer(NULL, [self.pixelBufferAdaptor pixelBufferPool], &pixelBuffer);
    
    CVPixelBufferLockBaseAddress(pixelBuffer, 0);
    
    void * data = CVPixelBufferGetBaseAddress(pixelBuffer);
    
    CGContextRef context = CGBitmapContextCreate(data, self.outputSize.width, self.outputSize.height, 8, CVPixelBufferGetBytesPerRow(pixelBuffer), CGColorSpaceCreateDeviceRGB(),  kCGBitmapByteOrder32Little | kCGImageAlphaPremultipliedFirst);
    
    CGContextDrawImage(context, CGRectMake(0, 0, self.outputSize.width, self.outputSize.height), image.CGImage);
    
    CVPixelBufferUnlockBaseAddress(pixelBuffer, 0);
    
    CGContextRelease(context);
    
    return pixelBuffer;
}


#pragma mark ======================================= 代理方法 =======================================

- (void)captureOutput:(AVCaptureOutput *)output didOutputSampleBuffer:(CMSampleBufferRef)sampleBuffer fromConnection:(AVCaptureConnection *)connection{
    
    if ((self.status = LJPRecordStatusRecording)) {
        
        if (self.isFirstWriter) {
            
            self.isFirstWriter = !self.isFirstWriter;
            
            // 开始写入
            [self.writer startWriting];
            
            //设置写入器的写入时间
            [self.writer startSessionAtSourceTime:CMSampleBufferGetPresentationTimeStamp(sampleBuffer)];
            
        }
        
        if (output == self.audioOutput){
            
            [self audioAddSampleBuffer:sampleBuffer];
            
            [self videoAddPixelBufferWithSampleBuffer:sampleBuffer];
            
        }
        
    }
    
}

#pragma mark ======================================= 访问器方法 =======================================

- (AVCaptureSession *)recordSession {
    if (_recordSession == nil) {
        _recordSession = [[AVCaptureSession alloc] init];
        
        //添加麦克风的输出
        if ([_recordSession canAddInput:self.audioMicInput]) {
            [_recordSession addInput:self.audioMicInput];
        }
        
        //添加音频输出
        if ([_recordSession canAddOutput:self.audioOutput]) {
            [_recordSession addOutput:self.audioOutput];
        }
        
    }
    return _recordSession;
}

//麦克风
- (AVCaptureDeviceInput *)audioMicInput {
    if (_audioMicInput == nil) {
        AVCaptureDevice *mic = [AVCaptureDevice defaultDeviceWithMediaType:AVMediaTypeAudio];
        NSError *error;
        _audioMicInput = [AVCaptureDeviceInput deviceInputWithDevice:mic error:&error];
        if (error) {
            NSLog(@"=========获取麦克风失败=========");
        }
    }
    return _audioMicInput;
}

//音频输出
- (AVCaptureAudioDataOutput *)audioOutput {
    if (_audioOutput == nil) {
        _audioOutput = [[AVCaptureAudioDataOutput alloc] init];
        [_audioOutput setSampleBufferDelegate:self queue:self.audioQueue]; //这里设置了代理和队列
    }
    return _audioOutput;
}

@end

// UISaveVideoAtPathToSavedPhotosAlbum
// NSString *videoPath, //保存的视频文件路径 id completionTarget, //回调的执行者 SEL completionSelector,//回调方法 void *contextInfo//回调参数信息

//- (UIImage *)snapshotAtTime:(CFTimeInterval)time withSize:(CGSize)size antialiasingMode:(SCNAntialiasingMode);
//在指定的时间（系统时间）将接收者的场景渲染成图像。antialiasingMode:应该是设置清晰度的


//CVPixelBufferPoolCreatePixelBuffer(CFAllocatorRef CV_NULLABLE allocator,CVPixelBufferPoolRef CV_NONNULL pixelBufferPool,CV_RETURNS_RETAINED_PARAMETER CVPixelBufferRef CV_NULLABLE * CV_NONNULL pixelBufferOut ) __OSX_AVAILABLE_STARTING(__MAC_10_4,__IPHONE_4_0);
//@function CVPixelBufferPoolCreatePixelBuffer
//   @abstract从池中创建一个新的PixelBuffer对象。
//   @discussion该函数使用池创建过程中指定的像素缓冲区属性创建一个新的（无附件的）CVPixelBuffer。
//   @param分配器用于创建像素缓冲区的CFAllocatorRef。 可能是NULL。
//   @param pool应该创建新的CVPixelBuffer的CVPixelBufferPool。
//   @param pixelBufferOut新创建的像素缓冲区将放置在这里
//   @result成功返回kCVReturnSuccess





