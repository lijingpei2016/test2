//
//  ViewController.m
//  控制动画
//
//  Created by LJP on 15/12/17.
//  Copyright © 2017年 poco. All rights reserved.
//

#import "ViewController.h"

@interface ViewController () <ARSCNViewDelegate>

@property (nonatomic, strong) IBOutlet ARSCNView *sceneView;

@property (nonatomic, strong) NSMutableDictionary * animations;

@property (nonatomic, assign) BOOL idle;

@end

    
@implementation ViewController

#pragma mark ======================== 生命周期 ========================

- (void)viewDidLoad {
    
    [super viewDidLoad];

    self.sceneView.delegate = self;
    
    self.sceneView.showsStatistics = YES;
    
    SCNScene *scene = [[SCNScene alloc]init];
    
    self.sceneView.scene = scene;
    
    self.animations = [[NSMutableDictionary alloc]init];
    
    [self loadAnimations];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    ARWorldTrackingConfiguration *configuration = [ARWorldTrackingConfiguration new];

    [self.sceneView.session runWithConfiguration:configuration];
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    
    [self.sceneView.session pause];
}


#pragma mark ======================== 私有方法 ========================

- (void)loadAnimations {
    
    SCNScene * idleScene = [SCNScene sceneNamed:@"art.scnassets/idleFixed.dae"]; //获取.dae文件都是用SCNScene来接收
    
    SCNNode * node = [[SCNNode alloc]init];  //一个节点可以有很多子节点
    
    for (SCNNode * child in idleScene.rootNode.childNodes) {
        [node addChildNode:child];
    }
    
    SCNVector3 extractedExpr = SCNVector3Make(0, -1, -2);
    node.position = extractedExpr;
    node.scale    = SCNVector3Make(0.2, 0.2, 0.2); //模型的大小
    
    [self.sceneView.scene.rootNode addChildNode:node];
    
    [self loadAnimationWithKey:@"dancing" sceneName:@"art.scnassets/twist_danceFixed" animationIdentifier:@"twist_danceFixed-1"];
    
}


// 把动画准备好 装在字典里
- (void)loadAnimationWithKey:(NSString *)key sceneName:(NSString *)sceneName animationIdentifier:(NSString *)animationIdentifier {
    
    NSString * sceneURL = [[NSBundle mainBundle] pathForResource:sceneName ofType:@"dae"];
    
    NSURL * url = [NSURL fileURLWithPath:sceneURL];
    
    SCNSceneSource * sceneSource = [SCNSceneSource sceneSourceWithURL:url options:nil];
    
    //在场景源中返回指定的类
    CAAnimation * animationObject = [sceneSource entryWithIdentifier:animationIdentifier withClass:[CAAnimation class]];
    
    if (animationObject) {
        NSLog(@"获取到了这个对象");
        animationObject.repeatCount = 1; //动画次数
        animationObject.fadeInDuration  = 1.0; //让动画开始得没那么突兀
        animationObject.fadeOutDuration = 0.5;
        
        [self.animations setObject:animationObject forKey:key];;
        
    }
    
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    
    NSLog(@"点击了屏幕");
    
    // 获取到手势的对象
    UITouch *touch = [touches allObjects].firstObject;
    
    // 手势在SCNView中的位置
    CGPoint touchPoint = [touch locationInView:self.sceneView];
    
    //该方法会返回一个SCNHitTestResult数组，这个数组中每个元素的node都包含了指定的点（CGPoint）
    NSArray *hitResults = [self.sceneView hitTest:touchPoint options:nil];
    
    if (hitResults.count > 0) {
        if (self.idle) {
            [self playAnimation:@"dancing"];
        }else{
            [self stopAnimation:@"dancing"];
        }
        self.idle = !self.idle;
        return;
    }
    
}

- (void)playAnimation:(NSString *)key {
    CAAnimation * animationObject = self.animations[key];
    if (animationObject) {
        [self.sceneView.scene.rootNode addAnimation:animationObject forKey:key];
    }
}

- (void)stopAnimation:(NSString *)key {

    [self.sceneView.scene.rootNode removeAnimationForKey:key blendOutDuration:0.5];
    
}

@end




