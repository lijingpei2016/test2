//
//  ViewController.m
//  第二个铺抓平面
//
//  Created by LJP on 6/12/17.
//  Copyright © 2017年 poco. All rights reserved.
//

#import "ViewController.h"
#import "Plane.h"

@interface ViewController () <ARSCNViewDelegate,ARSessionDelegate>

@property (nonatomic, strong)NSMutableDictionary * planes;

//视图
@property(nonatomic, strong) ARSCNView * jpARSCNView;

//会话
@property(nonatomic, strong) ARSession * jpARSession;

//跟踪会话
@property(nonatomic, strong) ARWorldTrackingConfiguration * jpARWTkConfiguration;

@end

    
@implementation ViewController

- (void)viewDidLoad {
    
    [super viewDidLoad];
    
    [self.view addSubview:self.jpARSCNView];
    
    self.planes = [[NSMutableDictionary alloc]init];
    
}

- (void)viewWillAppear:(BOOL)animated {
    
    [super viewWillAppear:animated];
    
    [self.jpARSCNView.session runWithConfiguration:self.jpARWTkConfiguration];
    
}

- (void)renderer:(id<SCNSceneRenderer>)renderer didAddNode:(SCNNode *)node forAnchor:(ARAnchor *)anchor {
    
    
    // 检测到新平面时创建 SceneKit 平面以实现 3D 视觉化

    ARPlaneAnchor * planeAnchor = (ARPlaneAnchor *)anchor;
    
    Plane * jpPlane = [[Plane alloc]initWithAnchor:planeAnchor];
    
    NSUUID * uuid = anchor.identifier;
    
    NSString * str = [uuid UUIDString];
        
    [self.planes setObject:jpPlane forKey:str];

    [node addChildNode:jpPlane];

}

-(void)renderer:(id<SCNSceneRenderer>)renderer didUpdateNode:(SCNNode *)node forAnchor:(ARAnchor *)anchor {
    
    // anchor 更新后也需要更新 3D 几何体。例如平面检测的高度和宽度可能会改变，所以需要更新 SceneKit 几何体以匹配
    //uuid用于区别是那一个几何图形  但是他是anchor里的信息
    
    NSUUID * uuid = anchor.identifier;
    
    NSString * str = [uuid UUIDString];
    
    Plane * jpPlane = self.planes[str];
    
    ARPlaneAnchor * planeAnchor = (ARPlaneAnchor *)anchor;
    
    [jpPlane update:planeAnchor];
    
}

-(void)renderer:(id<SCNSceneRenderer>)renderer didRemoveNode:(SCNNode *)node forAnchor:(ARAnchor *)anchor {
    
    NSUUID * uuid = anchor.identifier;
    
    NSString * str = [uuid UUIDString];
    
    [self.planes removeObjectForKey:str];
}


#pragma mark - 访问器方法

- (ARSCNView *)jpARSCNView {
    
    if (_jpARSCNView == nil) {
        _jpARSCNView = [[ARSCNView alloc]init];
        _jpARSCNView.frame = self.view.frame;
        _jpARSCNView.session = self.jpARSession;
        
        //自动刷新灯光
        _jpARSCNView.automaticallyUpdatesLighting = YES;
        
        _jpARSCNView.showsStatistics = YES;
        
        //添加默认灯光效果
        _jpARSCNView.autoenablesDefaultLighting = YES;
//
        // 开启 debug 选项以查看世界原点并渲染所有 ARKit 正在追踪的特征点
//        _jpARSCNView.debugOptions = ARSCNDebugOptionShowWorldOrigin | ARSCNDebugOptionShowFeaturePoints;
//        _jpARSCNView.debugOptions = ARSCNDebugOptionShowFeaturePoints;

        _jpARSCNView.delegate = self;
        
    }
    
    return _jpARSCNView;
}

- (ARSession *)jpARSession {
    
    if (_jpARSession == nil) {
        _jpARSession = [[ARSession alloc]init];
        
    }
    
    return _jpARSession;
    
}

- (ARWorldTrackingConfiguration *)jpARWTkConfiguration {
    
    if (_jpARWTkConfiguration == nil) {
        _jpARWTkConfiguration = [[ARWorldTrackingConfiguration alloc]init];
        _jpARWTkConfiguration.planeDetection = ARPlaneDetectionHorizontal;
        _jpARWTkConfiguration.lightEstimationEnabled = YES;
        
    }
    
    return _jpARWTkConfiguration;
    
}


@end
