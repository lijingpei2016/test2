//
//  Plane.m
//  第二个铺抓平面
//
//  Created by LJP on 6/12/17.
//  Copyright © 2017年 poco. All rights reserved.
//

#import "Plane.h"
#import "math.h"


@implementation Plane


-(instancetype)initWithAnchor:(ARPlaneAnchor *)anchor {
    
    self = [super init];
    
    if (self) {
        
        self.anchor = anchor;
        
        //extent 范围
        CGFloat w = anchor.extent.x;
        
        CGFloat h = anchor.extent.z;
        
        _planeGeometry = [SCNPlane planeWithWidth:w height:h];
        
        SCNMaterial * material = [[SCNMaterial alloc]init];
        
        UIImage * image = [UIImage imageNamed:@"fabric"];
        
        //扩散 - diffuse
        material.diffuse.contents = image;
        
        material.lightingModelName = SCNLightingModelPhysicallyBased;
        
        _planeGeometry.materials = @[material];
        
        SCNNode * planeNode = [SCNNode nodeWithGeometry:_planeGeometry];
        
        planeNode.position = SCNVector3Make(anchor.center.x, 0, anchor.center.z);
        
        // SceneKit 里的平面默认是垂直的，所以需要旋转90度来匹配 ARKit 中的平面
        CGFloat x = -M_PI/2.0;
        planeNode.transform = SCNMatrix4MakeRotation(x, 1.0, 0.0, 0.0);
        
        [self setTextureScale];
        
        [self addChildNode:planeNode];
        
    }
    
    return self;
}

- (void)setTextureScale {
    
    CGFloat w = self.planeGeometry.width;
    CGFloat h = self.planeGeometry.height;
    
    SCNMaterial * material = self.planeGeometry.materials[0];
    
    material.diffuse.contentsTransform = SCNMatrix4MakeScale(w, h, 1);
    
    material.diffuse.wrapS = SCNWrapModeRepeat;
    
    material.diffuse.wrapT = SCNWrapModeRepeat;
        
}

- (void)update:(ARPlaneAnchor* )anchor {
    
    // 随着用户移动，平面 plane 的 范围 extend 和 位置 location 可能会更新。
    // 需要更新 3D 几何体来匹配 plane 的新参数。
    CGFloat w = anchor.extent.x;
    CGFloat h = anchor.extent.z;
    
    self.planeGeometry.width  = w;
    self.planeGeometry.height = h;

    // plane 刚创建时中心点 center 为 0,0,0，node transform 包含了变换参数。
    // plane 更新后变换没变但 center 更新了，所以需要更新 3D 几何体的位置
    self.position = SCNVector3Make(anchor.center.x, 0, anchor.center.z);
    
    [self setTextureScale];
    
}

@end
